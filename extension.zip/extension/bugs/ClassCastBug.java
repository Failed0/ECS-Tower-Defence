package bugs;

public class ClassCastBug extends Bug{
    public ClassCastBug(String name, int level, int initialSteps) {
        super(name, 250, 9, level, initialSteps);
    }
}
