package bugs;

public class OutOfBoundBug extends Bug{
    public OutOfBoundBug(String name, int level, int initialSteps) {
        super(name, 70, 10, level, initialSteps);
    }
}
